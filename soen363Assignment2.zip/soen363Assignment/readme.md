soen363 A2 
Jingnan Wang (40282296)
Marina Girgis (40168639)
